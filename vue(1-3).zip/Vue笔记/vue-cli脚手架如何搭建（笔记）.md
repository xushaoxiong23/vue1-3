vue-cli脚手架如何搭建（笔记）



前提条件：已安装 node.js & npm
1.先安装 cnpm ：(会比npm快一些)
npm install -g cnpm --registry=https://registry.npm.taobao.org


2.再安装 vue-cli：
cnpm install -g vue-cli


3.安装完毕。
输入vue 回车，看是否安装成功


4.在项目文件夹的目录下，初始化生成一个项目，基于 webpack 模板，并创建一个新文件夹(命名为myproject)用于存放所有项目文件：
vue init webpack myproject


5.接下来，在项目目录下安装项目依赖（安装完的依赖包会存放在node_modules目录下）：
cnpm install

另外，可以用 vue list 命令列出所有模板


6.OK，运行：
npm run dev
运行成功，可通过localhost:8080访问页面

目录
脚手架搭好之后，后期开发基本都在src目录下进行
vue-cli脚手架如何搭建（笔记）_



如果出现 npm: 2.15.1 should be >= 3.0.0

 解：cmd 中执行 
把npm升级一下就可以了，npm install npm@latest -g 这句命令行就是升级到最新版的npm

